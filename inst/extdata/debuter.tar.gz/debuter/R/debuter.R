#' Package pour la formation "Débuter en R"
#' Contient les vignettes (les slides de cours), le jeu de données "fruits", le jeu de données "nutrimenu"  et les tutoriels. https://vguillemot.github.io/debuter/
#' @keywords internal
"_PACKAGE"
