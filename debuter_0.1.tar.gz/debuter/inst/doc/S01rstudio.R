## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)
library(ggplot2)

## ----4panneaux bis, echo = FALSE, out.width = "100%", cache = TRUE------------
dat <- data.frame(x = rep(1:2, 2), y = rep(2:1, e = 2), P = factor(1:4))
img <- png::readPNG("img/S01rstudio/Rstudio4panneaux.png")
g <- ggplot(dat, aes(x, y, fill = P, label = P)) +
  ggpubr::background_image(img) +
  geom_tile(show.legend = FALSE, alpha = 0.5) + 
  geom_point(aes(color = P), size = 30, shape = 21, fill = "white", 
             show.legend = FALSE) +
  geom_text(aes(color = P), vjust = 0.5, hjust = 0.5, size = 20, 
            show.legend = FALSE) + 
  theme_void()
print(g)

## ----4panneaux ter, echo = FALSE, out.width = "100%", cache = TRUE------------
print(g)

