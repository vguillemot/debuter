## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)
library(tidyr)
library(ggplot2)
data("fruits", package = "debuter")

## ----keewee, echo = FALSE, fig.width = 8, fig.height = 5----------------------
data.frame(i = 0:10,
           p = dbinom(0:10, 10, 0.5),
           col = rep(c("A", "B"), c(9, 2))) %>%
  ggplot(aes(i, p, fill = col)) +
  geom_col(show.legend = FALSE) +
  theme_minimal() +
  scale_x_continuous(breaks = 0:10) +
  labs(x = "", y = "")

## ----histvitC, fig.width = 3, fig.height=3, message=FALSE---------------------
qplot(fruits$Energie)
energiequal <- cut(fruits$Energie, 
                c(0, 250, 2000))

## ----histEau, fig.width = 3, fig.height=3, message=FALSE----------------------
qplot(fruits$Eau)
eauqual <- cut(fruits$Eau, 
               c(0, 85, 100))

## ----table--------------------------------------------------------------------
(tab <- table(energiequal, eauqual))

## ----prop.table---------------------------------------------------------------
prop.table(tab)

## ----prop.table1--------------------------------------------------------------
prop.table(tab, margin = 1)

## ----prop.table2--------------------------------------------------------------
prop.table(tab, margin = 2)

## ----prop.test----------------------------------------------------------------
prop.test(table(energiequal, eauqual))

## ----propex-------------------------------------------------------------------
smokers  <- c( 83, 90, 129, 70 )
patients <- c( 86, 93, 136, 82 )
prop.test(smokers, patients)

## ----chisq.test---------------------------------------------------------------
chisq.test(energiequal, eauqual)

## ----exchi2-------------------------------------------------------------------
M <- as.table(rbind(c(762, 327, 468), c(484, 239, 477)))
dimnames(M) <- list(gender = c("F", "M"),
                    party = c("Democrat","Independent", "Republican"))
(Xsq <- chisq.test(M))  # Prints test summary
Xsq$expected   # expected counts under the null

## ----fisher.test--------------------------------------------------------------
fisher.test(energiequal, eauqual)

## ----exfisher-----------------------------------------------------------------
Convictions <- matrix(
  c(2, 10, 15, 3), 
  nrow = 2,
  dimnames = list(
    c("Dizygotic", "Monozygotic"),
    c("Convicted", "Not convicted")))
fisher.test(Convictions, alternative = "less")

## ----t.test-------------------------------------------------------------------
t.test(fruits$VitamineC ~ eauqual)

## ----exttest------------------------------------------------------------------
t.test(extra ~ group, data = sleep)

## ----wilcox.test, warning = TRUE----------------------------------------------
wilcox.test(fruits$VitamineC ~ eauqual)

## ----pvalrecup----------------------------------------------------------------
res.ttest <- t.test(fruits$VitamineC ~ eauqual)
pval <- res.ttest$p.value

## ----aov----------------------------------------------------------------------
summary(aov(VitamineC ~ groupe, data = fruits))

## ----pvalaov------------------------------------------------------------------
res <- summary(aov(VitamineC ~ groupe, data = fruits))
res[[1]]$`Pr(>F)`[1]

## ----kruskal------------------------------------------------------------------
kruskal.test(fruits$VitamineC, fruits$groupe)

## ----cor.test-----------------------------------------------------------------
cor.test(fruits$Eau, fruits$Energie)

## ----excortest----------------------------------------------------------------
x <- c(44.4, 45.9, 41.9, 53.3, 44.7, 44.1, 50.7, 45.2, 60.1)
y <- c( 2.6,  3.1,  2.5,  5.0,  3.6,  4.0,  5.2,  2.8,  3.8)

cor.test(x, y, method = "kendall", alternative = "greater")

## ----lm-----------------------------------------------------------------------
res.lm <- lm(Energie ~Proteines + Sucres + Fibres + Eau, 
             data = fruits)
summary(res.lm)

