## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)

## ----fruits-------------------------------------------------------------------
library(dplyr)
data("fruits", package = "debuter")

## ----fruits2------------------------------------------------------------------
fruits2 <- fruits

## ----addSucresRatio-----------------------------------------------------------
fruits2$Sucres_ratio <- fruits2$Sucres / 100

## ----fruits2mod, eval = FALSE-------------------------------------------------
#  fruits2$recyclage <- c(0, 1)

## ----mtcars recyclage---------------------------------------------------------
mtcars2 <- mtcars
mtcars2$recyclage <- c(0, 1)
mtcars2$recyclage

## ----out.width="70%", fig.align='center', fig.width=3, fig.height=4-----------
## Histogramme
hist(fruits$Energie)

## ----out.width="70%", fig.align='center', message=FALSE, fig.width=3, fig.height=4----
library(magrittr)
fruits$Energie %>% hist()

## ----charger dplyr, message = FALSE-------------------------------------------
library(dplyr) # ou require(dplyr)

## ----charger tidyverse, eval = FALSE------------------------------------------
#  library(tidyverse)

## ----fruitibble---------------------------------------------------------------
fruits

## ----mutate1------------------------------------------------------------------
fruits2 <- fruits %>% 
  mutate(Sucres_ratio = Sucres / 100)

head(fruits2[, "Sucres_ratio"])

## ----mutate_classic-----------------------------------------------------------
fruits2 <- fruits
fruits2$Sucres_ratio <- 
  fruits2$Sucres / 100
head(fruits2[, "Sucres_ratio"])

## ----select, eval = FALSE-----------------------------------------------------
#  fruits %>%
#    select(
#      Energie,
#      Sucres,
#      Lipides,
#      Proteines)

## ----select_classic, eval = FALSE---------------------------------------------
#  fruits[,
#    c(
#      "Energie",
#      "Sucres",
#      "Lipides",
#      "Proteines")]

## ----selectbis, eval = FALSE--------------------------------------------------
#  fruits %>%
#    select(Energie:Proteines, - Eau)

## ----arrange------------------------------------------------------------------
fruits %>% 
  select(Energie, Sucres, Fibres) %>%
  arrange(desc(Fibres))

## ----arrange_classic----------------------------------------------------------
fruits[
  order(fruits$Fibres, decreasing = TRUE),
  c("Energie", "Sucres", "Fibres")]

## ----filter-------------------------------------------------------------------
fruits %>% 
  filter(Sucres > 60)

## ----filter_classic-----------------------------------------------------------
fruits[fruits$Sucres > 60, ]

## ----slice--------------------------------------------------------------------
fruits %>% 
  slice(3:10)

## ----slice_classic------------------------------------------------------------
fruits[3:10, ]

## ----group--------------------------------------------------------------------
fruits %>% group_by(groupe)

## ----summarize----------------------------------------------------------------
fruits %>% 
  group_by(groupe) %>%
  summarize(SucreMoyen = mean(Sucres))

## ----summarize_classic--------------------------------------------------------
aggregate(fruits$Sucres, 
          by = list(fruits$groupe), 
          FUN = mean)

## ----count--------------------------------------------------------------------
fruits %>% count(groupe)

## ----countArrange-------------------------------------------------------------
fruits %>%
  count(groupe) %>%
  arrange(desc(n))

## ----compte2choses------------------------------------------------------------
fruits %>%
  mutate(VitCqual = cut(VitamineC, c(0, 50, 100))) %>%
  count(groupe, VitCqual, name = "N")

## ----contingence, message=FALSE-----------------------------------------------
library(tidyr)
fruits %>%
  mutate(VitCqual = cut(VitamineC, c(0, 50, 100))) %>%
  count(groupe, VitCqual, name = "N") %>%
  pivot_wider(id_cols = groupe, 
              names_from = VitCqual, 
              values_from = N)

