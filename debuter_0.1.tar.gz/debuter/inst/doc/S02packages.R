## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)

## ----install, eval = FALSE----------------------------------------------------
#  remotes::install_github("vguillemot/debuter")

