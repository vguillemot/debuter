## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE,
  dev = "svg",
  fig.ext = "svg"
)
library(ggplot2)

## ----RColorBrewer-------------------------------------------------------------
library(RColorBrewer)

## ----data---------------------------------------------------------------------
data("fruits", package = "debuter")

## ----eval = FALSE, echo = FALSE-----------------------------------------------
#  ------- ------- ---------- ---------- ----------- --------- -------- -------------- -------
#  Entier     1        2          3          4          5         6           7           8
#  HEX     #000000 #DF536B    #61D04F    #2297E6     #28E2E5   #CD0BBC  #F5C710        #9E9E9E
#  Couleur black   indianred2 palegreen3 dodgerblue2 turquoise magenta3 darkgoldenrod1 gray62
#  ------- ------- ---------- ---------- ----------- --------- -------- -------------- -------

## ----kableextra, echo = FALSE, results='asis', message=FALSE, warning=FALSE----
library(kableExtra)

coltab <- read.table(text = 
"Entier 1 2 3 4 
Nom black indianred2 palegreen3 dodgerblue2
HEX #000000 #DF536B #61D04F #2297E6 
Entier 5 6 7 8
Nom turquoise magenta3 darkgoldenrod1 gray62
HEX #28E2E5 #CD0BBC #F5C710 #9E9E9E", comment.char = "")

coltab$V2 <- cell_spec(coltab$V2, color = rep(c("black", "turquoise"), each = 3))
coltab$V3 <- cell_spec(coltab$V3, color = rep(c("indianred", "magenta"), each = 3))
coltab$V4 <- cell_spec(coltab$V4, color = rep(c("palegreen", "darkgoldenrod"), each = 3))
coltab$V5 <- cell_spec(coltab$V5, color = rep(c("dodgerblue", "gray"), each = 3))

coltab %>%
   kable(escape = FALSE, col.names = c("", "", "", "", ""), table.attr = "style='width:100%;'", align = c("l", "c", "c", "c", "c")) %>%
   kable_styling(full_width = TRUE) %>%
   column_spec(1, bold = FALSE, border_right = TRUE, color = "white", background = "black")

## ----couleurs-----------------------------------------------------------------
barplot(rep(1,8), col = 1:8)

## ----colors-------------------------------------------------------------------
sample(colors(), 7)

## ----hex, echo = FALSE, fig.height = 2.5, fig.width = 6-----------------------
hexdat <- data.frame(
  x = 1:6,
  col = rep(c("#FF0000", "#00FF00", "#0000FF"), each = 2)
)

zesize <- 20

ggplot(hexdat, aes(x = x)) + 
  geom_point(aes(color = I(col)), y = 1, size = zesize) + 
  annotate("text", x = 0, y = 1, label = "#", size = zesize) + 
  theme_minimal() + 
  xlim(c(-0.2, 6.2)) + 
  theme_void()

## ----barplot3façons, eval = FALSE---------------------------------------------
#  barplot(rep(1, 3), col = 2:4)
#  barplot(rep(1, 3), col = c("indianred2", "palegreen3", "dodgerblue2"))
#  barplot(rep(1, 3), col = c("#DF536B", "#61D04F", "#2297E6"))

## ----legraphe3facons, echo = FALSE, fig.height = 2.5--------------------------
barplot(rep(1, 3), col = 2:4)

## ----couleurs_repetees, fig.height = 2----------------------------------------
par(mar = c(0, 0, 0, 0))
barplot(rep(1,80), col = 1:8, border = NA, space = 0, axes = FALSE)

## ----displayAll, eval = FALSE-------------------------------------------------
#  display.brewer.all()

## ----brewer.pal---------------------------------------------------------------
brewer.pal(n = 3, name = "Set3")

## ----couleurexo1, eval = FALSE------------------------------------------------
#  pal <- brewer.pal(***, ***)
#  barplot(rep(1, 7),
#          col = pal,
#          axes = ***,
#          border = ***)

## ----colorRamp----------------------------------------------------------------
colfun <- colorRampPalette(c("darkorchid", "black", "limegreen"))
barplot(rep(1, 30), col = colfun(30), axes = F, border = NA)

## ----couleurexo2, eval = FALSE------------------------------------------------
#  colfun <- colorRampPalette(
#    c(***, ***, ***))
#  barplot(rep(1, 100),
#          col = colfun(100),
#          axes = F, border = NA)
#  

## ----hexalpha, echo = FALSE, fig.height = 2.5, fig.width = 6------------------
hexdat <- data.frame(
  x = 1:8,
  col = rep(c("#FF0000", "#00FF00", "#0000FF", "#11111170"), each = 2)
)

zesize <- 20

ggplot(hexdat, aes(x = x)) + 
  geom_point(aes(color = I(col)), y = 1, size = zesize) + 
  annotate("text", x = 0, y = 1, label = "#", size = zesize) + 
  theme_minimal() + 
  xlim(c(-0.2, 8.2)) + 
  theme_void()

## ----couleuralphaexo3, eval = FALSE-------------------------------------------
#  colfun <- colorRampPalette(
#    c("#FFAA00FF", ***),
#    alpha = TRUE)
#  barplot(***,
#          col = colfun(100),
#          axes = F, border = NA)
#  

## ----ggpubr, message = FALSE--------------------------------------------------
library(ggpubr)

## ----scale_fill_brewer, eval = FALSE------------------------------------------
#  ggplot(fruits, aes(x = groupe,
#                     fill = groupe)) +
#    geom_bar() +
#    scale_fill_brewer(palette = "Set1") +
#    theme_bw()

## ----scale_fill_brewer2, echo = FALSE, fig.width = 5, out.width="100%"--------
ggplot(fruits, aes(x = groupe,
                   fill = groupe)) + 
  geom_bar() + 
  scale_fill_brewer(palette = "Set1") + 
  theme_bw()

## ----scale_color_distiller, eval = FALSE--------------------------------------
#  ggplot(fruits, aes(x = Phosphore,
#                     y = Calcium,
#                     color = Magnesium)) +
#    geom_point() +
#    scale_color_distiller(palette = "PuOr") +
#    theme_bw()

## ----scale_color_distiller2, echo = FALSE, fig.width = 5, out.width="100%"----
ggplot(fruits, aes(x = Phosphore,
                   y = Calcium,
                   color = Magnesium)) + 
  geom_point() + 
  scale_color_distiller(palette = "PuOr") + 
  theme_bw()

## ----scale_fill_manual, eval = FALSE------------------------------------------
#  ggplot(fruits, aes(x = groupe,
#                     fill = groupe)) +
#    geom_bar() +
#    scale_fill_manual(
#      values = c(crus = "violet",
#                 secs = "brown3",
#                 exotique = "limegreen",
#                 compote = "skyblue")) +
#    theme_bw()

## ----scale_fill_manual2, echo = FALSE, fig.width = 5, out.width="100%"--------
ggplot(fruits, aes(groupe, fill = groupe)) + 
  geom_bar() + 
  scale_fill_manual(
    values = c(crus = "violet", secs = "brown3", 
               exotique = "limegreen", compote = "skyblue")) + 
  theme_bw()

## ----scale_color_gradient, eval = FALSE---------------------------------------
#  ggplot(fruits, aes(x = Phosphore,
#                     y = Calcium,
#                     color = Magnesium)) +
#    geom_point() +
#    scale_color_gradient(
#      low = "limegreen",
#      high = "violet") +
#    theme_bw()

## ----scale_color_gradient2, echo = FALSE, fig.width = 5, out.width="100%"-----
ggplot(fruits, aes(x = Phosphore,
                   y = Calcium,
                   color = Magnesium)) + 
  geom_point() + 
  scale_color_gradient(
    low = "limegreen",
    high = "violet") + 
  theme_bw()

## ----signif, warning=FALSE, fig.height=4--------------------------------------
ggplot(fruits, aes(groupe, VitamineC)) + 
  geom_boxplot(aes(color = groupe)) + 
  geom_signif(comparisons = list(c("crus", "exotique"))) + 
  theme_bw()

## ----ggarrange, warning=FALSE, message=FALSE, fig.height=4--------------------
g1 <- ggplot(fruits, aes(Eau)) + geom_histogram()
g2 <- ggplot(fruits, aes(Energie)) + geom_histogram()
ggarrange(g1, g2, labels = "AUTO")

## ----UpSetR, message = FALSE--------------------------------------------------
library(ggvenn)

## ----flist--------------------------------------------------------------------
flist <- list(
    Sucres = fruits$nom[fruits$Sucres > 20],
    Fibres = fruits$nom[fruits$Fibres > 2],
    Energie = fruits$nom[fruits$Energie > 50],
    Potassium = fruits$nom[fruits$Potassium > 100]
)

## ----venn, fig.height = 4, fig.width = 8--------------------------------------
ggvenn(flist, set_name_size = 4)

## ----sauvenn, eval = FALSE----------------------------------------------------
#  g <- ggvenn(flist, set_name_size = 4)
#  ggsave(filename = "fruit_venn.pdf", plot = g)

## ----pheatmap-----------------------------------------------------------------
library(pheatmap)

## ----essai1, eval = FALSE-----------------------------------------------------
#  pheatmap(fruits)

## ----essai2, eval = FALSE-----------------------------------------------------
#  pheatmap(fruits[, -(1:2)])

## ----essai2eval, echo = FALSE, fig.width = 4, fig.height = 5------------------
pheatmap(fruits[, -(1:2)])

## ----essai3, eval = FALSE-----------------------------------------------------
#  pheatmap(
#    fruits[, -(1:2)],
#    cluster_rows = FALSE,
#    scale = "column",
#    show_rownames = FALSE,
#    cellwidth = 10
#  )

## ----essai3eval, echo = FALSE, fig.width = 4, fig.height = 5------------------
pheatmap(
  fruits[, -(1:2)],
  cluster_rows = FALSE,
  scale = "column",
  show_rownames = FALSE,
  cellwidth = 10
)

## ----essai4, eval = FALSE-----------------------------------------------------
#  colfun <- colorRampPalette(
#    c("darkorchid",
#      "white",
#      "limegreen"))
#  
#  pheatmap(
#    fruits[, -(1:2)],
#    cluster_rows = FALSE,
#    scale = "column",
#    show_rownames = FALSE,
#    cellwidth = 10,
#    color = colfun(20)
#  )

## ----essai4eval, echo = FALSE, fig.width = 4, fig.height = 5------------------
colfun <- colorRampPalette(
  c("darkorchid", 
    "white", 
    "limegreen"))

pheatmap(
  fruits[, -(1:2)],
  cluster_rows = FALSE,
  scale = "column",
  show_rownames = FALSE,
  cellwidth = 10,
  color = colfun(20)
)

## ----essai5, eval = FALSE-----------------------------------------------------
#  colfun <- colorRampPalette(
#    c("darkorchid",
#      "white",
#      "limegreen"))
#  fruitsDF <- data.frame(
#    fruits[,-1],
#    row.names = make.unique(fruits$nom))
#  annotLignes <- fruitsDF[, "groupe",
#                          drop = FALSE]
#  
#  pheatmap(
#    fruitsDF[, -1],
#    cluster_rows = FALSE,
#    scale = "column",
#    show_rownames = FALSE,
#    cellwidth = 10,
#    color = colfun(20),
#    annotation_row = annotLignes
#  )

## ----essai5eval, echo = FALSE, fig.width = 4, fig.height = 5------------------
colfun <- colorRampPalette(c("darkorchid", "white", "limegreen"))
fruitsDF <- data.frame(fruits[,-1], row.names = make.unique(fruits$nom))
annotLignes <- fruitsDF[, "groupe", drop = FALSE]

pheatmap(
  fruitsDF[, -1],
  cluster_rows = FALSE,
  scale = "column",
  show_rownames = FALSE,
  cellwidth = 10,
  color = colfun(20), 
  annotation_row = annotLignes
)

## ----avous, eval = FALSE------------------------------------------------------
#  pheatmap(
#    t(fruits),
#    scale = "row",
#    color = c("black", "black"),
#    legend_breaks = c(-6, 0,+6),
#    border_color = "pink",
#    cellheight = 100,
#    cellwidth = 0.1,
#    show_colnames = "FALSE"
#  )

