# Ceci est un commentaire

## Exercice : le résultat est 2
1 + 1

# Pour installer ggplot2
install.packages("ggplot2")
# Pour charger le package ggplot2
library(ggplot2)
# ou bien
library("ggplot2")

# Installer BiocManager pour accéder 
# au packages Bioconductor (ww.bioconductor.org)
install.packages("BiocManager")
BiocManager::install("limma")

# Installer le package du cours
devtools::install_github("vguillemot/debuter",
                         build_vignettes = TRUE)
# Pour le charger
library(debuter)
?fruits

# Les objets
## Exercice qui fait 2
sqrt(log2(4) ^ (1 + 1))
## Exercice de suite d'entiers
c(3:1, 0:3)
c(seq(3, 1, -1), seq(0, 3))
## Exercice ab
a <- 0:3
b <- 3:1
ab <- c(b, a)
