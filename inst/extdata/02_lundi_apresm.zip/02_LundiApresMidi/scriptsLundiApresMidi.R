# Le nom des mois
month.name

## Tibble
install.packages("dplyr")
# Tableau des fruits
library(dplyr)
data("fruits", package = "debuter")
fruits



# Exercice booléen
1 == 2
!(5 > -6)
(1 <= 10) | (1 > 0)
log(1) != 0

# Tableau des fruits
library(dplyr)
data("fruits", package = "debuter")
fruits

## Guillemets
"Mme de Maintenont déclara 'Que nenni !'."
"Mme de Maintenont déclara "Que nenni !"." # ERREUR !

## Exercice : comment sélectionner les fruits 1, 3 et 5
fruits[c(1, 3, 5), ]
fruits[seq(1, 5, 2), ]
# fruits [1&3&5,] -> ERREUR

## Exercice : extraction piège
fruits[-(1:3), ]
fruits[-1:3, ] # Oubli des parenthèses

## Exercice : extraire la colonne "Sucres" de deux manières différentes
fruits$Sucres
fruits[, 8]
fruits[, "Sucres"]
teneurSucres <- fruits$Sucres
class(teneurSucres)
teneurSucres2 <- fruits[, 8]
class(teneurSucres2)
class(mtcars[, 1])

# Exemple de création et d'extraction sur un vecteur
i <- 1:10
eau <- fruits$Eau
eau[i]

## Exercice : créez un vecteur groupe et extraire les 10 première valeurs de deux façons différentes
i <- 1:10
groupe1 <- fruits$groupe
groupe1[i]
groupe2 <- fruits[, "groupe"]
groupe2[i, ]

## Booléens
fruits$Eau >= 60
fruits[fruits$Eau >= 60, ]
# En deux étapes
eauSup60 <- fruits$Eau >= 60
fruits[eauSup60, ]

## Exercice :  Extraire la teneur en proteines, glucides et lipides des fruits secs 
fruitsSecs <- fruits[fruits$groupe == "secs", ]
fruitsSecs[, 5:7]
# ou bien
fruitsSecs[, c(5, 6, 7)]
### En une seule ligne
fruits[fruits$groupe == "secs", 5:7]

### Changer le nom d'une colonne
colnames(fruits)[1] <- "LeNomDaisFrouits"
colnames(fruits)[1] <- "LeNomDesFruits"
### Changer une valeur
fruits$Energie[1:10] <- 0

data("fruits", package = "debuter")

## Extraire avec des noms
fruits[, "Energie"]
fruits[, "groupe"]
fruits[, c("groupe", "Energie")]
fruits[, -"groupe"]

## Exercice : Extraire les fruits crus sucrés riche en vitamine C
### Calculer la médiane de la teneur en sucres
median(fruits$Sucres) 
### Calculer les vecteurs de booléen
booleenCrus <- fruits$groupe == "crus" 
booleenSucres <- fruits$Sucres >= median(fruits$Sucres)
booleenVitC <- fruits$VitamineC >= median(fruits$VitamineC)
fruits[ booleenCrus & booleenSucres & booleenVitC, ]
## En une seule ligne
fruits[fruits$groupe == "crus" & fruits$Sucres >= median(fruits$Sucres) & fruits$VitamineC >= median(fruits$VitamineC), ]

## Exercice : estimation ponctuelle
median(fruits$Sucres)
mean(fruits$Eau)
sd(fruits$Eau)
summary(fruits)
summary(fruits$Eau)
cor(fruits$Eau, fruits$Sucres)
cor(fruits$Eau, fruits$Sucres, method="spearman")

## Fonctions astucieuses
str(fruits)
table(fruits$groupe)
seq_along(fruits$Eau)

## Histogrammes de la teneur en vit. C des fruits crus
hist(fruits$VitamineC[fruits$groupe == "crus"])
