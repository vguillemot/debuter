## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE
)
library(ggplot2)
library(tidyr)

## ----vecteur, echo = FALSE, results='asis'------------------------------------
pander::pandoc.table(c(3:1, 0:3))

## ----assign, echo = FALSE, fig.width = 3, fig.height = 3, fig.align='center'----
data.frame(x = 0, y = 0, lab = "<-") %>% 
  ggplot(aes(x, y, label = lab)) + 
  geom_text(size = 50, family = "Courier", fontface = "bold") + 
  theme_void() + 
  theme(plot.margin = unit(c(0, 0, 0, 0), "cm"))

## ----vecteur2, echo = FALSE, results='asis'-----------------------------------
pander::pandoc.table(c(3:1, 0:3))

## -----------------------------------------------------------------------------
a <- 1:5
a + 1
a * 2

## ----fruits-------------------------------------------------------------------
data("fruits", package = "debuter")
head(fruits)
dim(fruits)
nrow(fruits)
ncol(fruits)
fruits

## ----brackets, echo = FALSE, fig.width = 6, fig.height = 4, fig.align='center'----
data.frame(x = c(0, 1, 0, 1), y = c(1, 1, 0, 0), lab = c("[ ]", "[ , ]", "[[ ]]", "$")) %>% 
  ggplot(aes(x, y, label = lab, color = lab)) + 
  geom_text(aes(hjust = x, vjust = y), size = 20, family = "Courier", fontface = "bold", show.legend = FALSE) + 
  theme_void() + 
  theme(plot.margin = unit(c(0, 0, 0, 0), "cm"))

## ----barplot------------------------------------------------------------------
barplot(table(fruits$groupe))

## ----hist---------------------------------------------------------------------
hist(fruits$Eau)

## ----plot---------------------------------------------------------------------
plot(fruits$Eau, fruits$Sucres)

