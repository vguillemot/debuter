rmarkdown::render("vignettes/S00programme.Rmd")
rmarkdown::render("vignettes/S01rstudio.Rmd")
rmarkdown::render("vignettes/S02packages.Rmd")
rmarkdown::render("vignettes/S03objets.Rmd")
rmarkdown::render("vignettes/S04dplyr.Rmd")
rmarkdown::render("vignettes/S05ggplot2.Rmd")
rmarkdown::render("vignettes/S06visu.Rmd")
rmarkdown::render("vignettes/S07tests.Rmd")
rmarkdown::render("vignettes/S08input_output.Rmd")

## Créer alias Google Chrome
# alias chrome="/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome"
# https://tecadmin.net/create-pdf-google-chrome-headless/
# Exemple :
# chrome --headless --disable-gpu --print-to-pdf http://www.example.com/


alias chrome="/Applications/Google\ Chrome.app/Contents/MacOS/Google\ Chrome"
chrome --headless --disable-gpu --print-to-pdf=vignettes/S00programme.pdf vignettes/S00programme.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S01rstudio.pdf vignettes/S01rstudio.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S02packages.pdf vignettes/S02packages.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S03objets.pdf vignettes/S03objets.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S04dplyr.pdf vignettes/S04dplyr.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S05ggplot2.pdf vignettes/S05ggplot2.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S06visu.pdf vignettes/S06visu.html
chrome --headless --disable-gpu --print-to-pdf=vignettes/S08input\_output.pdf vignettes/S08input\_output.html


