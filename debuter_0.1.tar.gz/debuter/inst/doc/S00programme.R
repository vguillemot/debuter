## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  echo = TRUE, 
  dev = "svg"
)
library(dplyr)
library(ggplot2)


## ----pas 2 stats, echo = FALSE------------------------------------------------
data.frame(
  x = 1, 
  y = 1, 
  text = "Le but est d'apprendre R,\n pas les statistiques") %>% 
  ggplot(aes(x, y, label = text)) + 
  geom_text(color = "steelblue", size = 10, fontface = "bold") + 
  theme_void()

